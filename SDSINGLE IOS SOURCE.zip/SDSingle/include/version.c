const char *openconnect_version_str = "v6.00-unknown";
