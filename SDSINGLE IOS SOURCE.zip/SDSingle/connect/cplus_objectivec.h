//
//  cplus_objectivec.h
//  OpenConnectNew
//
//  Created by Chi Yu Lan on 4/10/18.
//  Copyright © 2018 NextVPN Corporation. All rights reserved.
//

#ifndef cplus_objectivec_h
#define cplus_objectivec_h
#include "openconnect.h"
#include "wrapper/base.h"
int tunnel(struct oc_ip_info *info_ip);
using namespace openconnect;
static TunBuilderBase *buider = 0 ;
#endif /* cplus_objectivec_h */
