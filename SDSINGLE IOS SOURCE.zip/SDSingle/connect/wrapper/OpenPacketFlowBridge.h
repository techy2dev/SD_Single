//
//  OpenVPNPacketFlowBridge.h
//  OpenVPN Adapter
//
//  Created by Chi Yu Lan on 12/10/2017.
//  Modified by Chi Yu Lan on 15/01/2018.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol OpenAdapterPacketFlow;

@interface OpenPacketFlowBridge: NSObject

@property (nonatomic, readonly) CFSocketRef openVPNSocket;
@property (nonatomic, readonly) CFSocketRef packetFlowSocket;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithPacketFlow:(id<OpenAdapterPacketFlow>)packetFlow NS_DESIGNATED_INITIALIZER;

- (BOOL)configureSocketsWithError:(NSError **)error;
- (void)startReading;

@end

NS_ASSUME_NONNULL_END
