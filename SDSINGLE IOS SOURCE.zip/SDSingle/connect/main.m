//
//  main.m
//  connect
//
//  Created by Chi Yu Lan on 4/11/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
