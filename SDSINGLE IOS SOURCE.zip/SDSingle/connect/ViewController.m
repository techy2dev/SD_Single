//
//  ViewController.m
//  connect
//
//  Created by Chi Yu Lan on 4/11/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import "ViewController.h"
#import <NetworkExtension/NETunnelProviderManager.h>
#import <NetworkExtension/NETunnelProviderProtocol.h>
#import <NetworkExtension/NEVPNConnection.h>
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *server;
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UISwitch *option;

@end

@implementation ViewController{
    __block NETunnelProviderManager * vpnManager;
    
}
static Boolean isConnect = false;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
}
- (void)initVPNTunnelProviderManager{
    NSString *tunnelBundleId = @"net.sdsingle.tunnel.Tunnel"; // Bundle of Extension
    
    [NETunnelProviderManager loadAllFromPreferencesWithCompletionHandler:^(NSArray* newManagers, NSError *error)
     {
         if(error != nil){
             NSLog(@"Load Preferences error: %@", error);
         }else{
             if([newManagers count] > 0)
             {
                 vpnManager = newManagers[0];
             }else{
                 vpnManager = [[NETunnelProviderManager alloc] init];
             }
             
             [vpnManager loadFromPreferencesWithCompletionHandler:^(NSError *error){
                 if(error != nil){
                     NSLog(@"Load Preferences error: %@", error);
                 }else{
                     __block NETunnelProviderProtocol *protocol = [[NETunnelProviderProtocol alloc] init];
                     protocol.providerBundleIdentifier = tunnelBundleId;
                     // get file
                     //NSString *path = [[NSBundle mainBundle] pathForResource:@"Windscribe-US-Central-UDP" ofType:@"ovpn"];
                     //NSString* content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL];
                     NSString *user = _username.text;
                     NSString *pass = _password.text;
                     NSString *server = _server.text;
                     
                     if(_option.isOn){
                         /*protocol.providerConfiguration = @{@"server": @"ondemand.tcdsb.org",
                                                            @"username": @"jiangk",
                                                            @"password": @"1234567890ok",
                                                            @"option": @"--protocol=gp"
                                                            }; // you can send username/password in here
                         */
                         protocol.providerConfiguration = @{@"server": _server.text,
                                                            @"username": user,
                                                            @"password": pass,
                                                            @"option": @"--protocol=gp"
                                                            };
                     }else{
                         protocol.providerConfiguration = @{@"server": _server.text,
                                                            @"username": user,
                                                            @"password": pass
                                                            }; // you can send username/password in here
                     }
                     
                     protocol.serverAddress = _server.text;
                     vpnManager.protocolConfiguration = protocol;
                     vpnManager.localizedDescription = @"144.76.6.200";
                     
                     [vpnManager setEnabled:true];
                     [vpnManager saveToPreferencesWithCompletionHandler:^(NSError *error){
                         if (error != nil) {
                             NSLog(@"Save to Preferences Error: %@", error);
                         }else{
                             NSLog(@"Save successfully");
                             
                             [[NSNotificationCenter defaultCenter] addObserver:self
                                                                      selector:@selector(receiveNotification:)
                                                                          name:NEVPNStatusDidChangeNotification
                                                                        object:nil];
                             [self openTunnel];
                         }
                     }];
                 }}];
         }
     }];
}

- (void) openTunnel{
    [vpnManager loadFromPreferencesWithCompletionHandler:^(NSError *error){
        if(error != nil){
            NSLog(@"%@", error);
        }else{
            NSError *startError = nil;
            [vpnManager.connection startVPNTunnelWithOptions:nil andReturnError:&startError];
            if(startError != nil){
                NSLog(@"%@", startError);
            }else{
                NSLog(@"Complete");
               // [self receiveNotification:nil];
            }
        }
    }];
}
- (IBAction)btnconnect:(id)sender {
    _uibtn.enabled = NO;
    if(isConnect){
        isConnect = false;
        [vpnManager.connection stopVPNTunnel];
        [_uibtn setTitle:@"CONNECT" forState:UIControlStateNormal];
        _uibtn.enabled = YES;
    }else{
        [_uibtn setTitle:@"CONNECTING" forState:UIControlStateNormal];
        [self initVPNTunnelProviderManager];
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (void) receiveNotification:(NSNotification *) notification{
    NEVPNStatus status = vpnManager.connection.status;
    
    UIAlertView *alert;
    if(status == NEVPNStatusInvalid){
        NSLog(@"NEVPNStatusInvalid");
        _uibtn.enabled = YES;
        alert = [[UIAlertView alloc] initWithTitle:@"Notification"
                                           message:@"wrong username or password"
                                          delegate:self
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil,nil];
        [alert show];
       // _tfButton.enabled = YES;
    }
    if(status == NEVPNStatusConnecting){
        [_uibtn setTitle:@"CONNECTING" forState:UIControlStateNormal];
        NSLog(@"NEVPNStatusConnecting");
        
    }
    if(status == NEVPNStatusReasserting){
        NSLog(@"NEVPNStatusReasserting");
        
    }
    if(status == NEVPNStatusConnected){
        NSLog(@"NEVPNStatusConnected");
        alert = [[UIAlertView alloc] initWithTitle:@"Notification"
                                           message:@"VPN Started"
                                          delegate:self
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil,nil];
        [alert show];
        isConnect = true;
        _uibtn.enabled = YES;
        //_tfButton.enabled = YES;
        [_uibtn setTitle:@"DISCONNECT" forState:UIControlStateNormal];
        //vpnManagerStatic = vpnManager;
       
    }
    if(status == NEVPNStatusDisconnected){
        NSLog(@"NEVPNStatusDisconnected");
        
        [_uibtn setTitle:@"RECONNECT" forState:UIControlStateNormal];
        _uibtn.enabled = YES;
    }
    if(status == NEVPNStatusDisconnecting){
        NSLog(@"NEVPNStatusDisconnecting");
    }
    return;
}

@end
