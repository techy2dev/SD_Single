//
//  OpenConnectAdapter.h
//  OpenConnectNew
//
//  Created by CYTECH on 4/9/18.
//  Copyright © 2018 NextVPN Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OpenConnectAdapter : NSObject
- (void) startWithOptions:(NSArray*)options;
@end
