//
//  Util.m
//  NETExtension
//
//  Created by CYTECH on 7/1/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import "Util.h"
#import <CommonCrypto/CommonDigest.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <SystemConfiguration/SystemConfiguration.h>
@implementation Util
// For IP

/*
 POST MAN
 #import <Foundation/Foundation.h>
 
 NSDictionary *headers = @{ @"content-type": @"application/x-www-form-urlencoded",
 @"cache-control": @"no-cache",
 @"postman-token": @"36967715-e22a-1a8e-6430-57df72fba138" };
 
 NSData *postData = [[NSData alloc] initWithData:[@"action=submit&pid=6&billingcycle=monthly&email=testfrompostman1&paymentmethod=paypal&password=testfrompostman1&password2=testfropostman1" dataUsingEncoding:NSUTF8StringEncoding]];
 
 NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://everythingcryptos.com/test.php"]
 cachePolicy:NSURLRequestUseProtocolCachePolicy
 timeoutInterval:10.0];
 [request setHTTPMethod:@"POST"];
 [request setAllHTTPHeaderFields:headers];
 [request setHTTPBody:postData];
 
 NSURLSession *session = [NSURLSession sharedSession];
 NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
 completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
 if (error) {
 NSLog(@"%@", error);
 } else {
 NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
 NSLog(@"%@", httpResponse);
 }
 }];
 [dataTask resume];
 */
+ (NSString *) getDataFrom:(NSString *)url{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"GET"];
    [request setURL:[NSURL URLWithString:url]];
    
    NSError *error = nil;
    NSHTTPURLResponse *responseCode = nil;
    
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    
    if([responseCode statusCode] != 200){
        NSLog(@"Error getting %@, HTTP status code %li", url, (long)[responseCode statusCode]);
        return nil;
    }
    
    return [[NSString alloc] initWithData:oResponseData encoding:NSUTF8StringEncoding];
}

+ (NSString *) getDataFrom:(NSString *)url username:(NSString *) user password:(NSString *)pass{
    NSDictionary *headers = @{ @"content-type": @"multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
                               @"cache-control": @"no-cache",
                               @"postman-token": @"a4c70d9d-a0d8-3ab8-cfbf-7d678a479814" };
    NSArray *parameters = @[ @{ @"name": @"email", @"value": @"test@gmail.com" },
                             @{ @"name": @"password", @"value": @"Password100!" } ];
    NSString *boundary = @"----WebKitFormBoundary7MA4YWxkTrZu0gW";
    
    NSError *error;
    NSMutableString *body = [NSMutableString string];
    for (NSDictionary *param in parameters) {
        [body appendFormat:@"--%@\r\n", boundary];
        if (param[@"fileName"]) {
            [body appendFormat:@"Content-Disposition:form-data; name=\"%@\"; filename=\"%@\"\r\n", param[@"name"], param[@"fileName"]];
            [body appendFormat:@"Content-Type: %@\r\n\r\n", param[@"contentType"]];
            [body appendFormat:@"%@", [NSString stringWithContentsOfFile:param[@"fileName"] encoding:NSUTF8StringEncoding error:&error]];
            if (error) {
                NSLog(@"%@", error);
            }
        } else {
            [body appendFormat:@"Content-Disposition:form-data; name=\"%@\"\r\n\r\n", param[@"name"]];
            [body appendFormat:@"%@", param[@"value"]];
        }
    }
    [body appendFormat:@"\r\n--%@--\r\n", boundary];
    NSData *postData = [body dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://everythingcryptos.com/mobile/login.php"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    __block NSString *dateResA = nil;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                        dateResA = @"";
                                                    } else {
                                                        //NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                        //NSLog(@"%@", httpResponse);
                                                        dateResA = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                    }
                                                }];
    [dataTask resume];
    while (!dateResA) {
        sleep(1);
    }
    return dateResA;
}

NSString static *APP_GROUP = @"group.co.evpn.ovpn";
NSString static *NE_BUNDLE_ID = @"co.evpn.ovpn.PacketTunnel";

+ (NSString *) getNEBundleId {
    return NE_BUNDLE_ID;
}

+ (NSString *) getAppGroup{
    return APP_GROUP;
}


+ (Boolean) removeVPNProfile:(NSString *) fileName{
    if(![fileName containsString:@".ovpn"]){
        [fileName stringByAppendingString:@".opvn"];
    }
    NSString *destinationPath = [[[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:[Util getAppGroup]] path] stringByAppendingPathComponent:fileName];
    [[NSFileManager defaultManager] removeItemAtPath:destinationPath error:nil];
    return true;
}

+ (BOOL) writeStringToFile:(NSString *)aString name_file:(NSString *) file_name{
    NSString *destinationPath = [[[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:[Util getAppGroup]] path] stringByAppendingPathComponent:file_name];
    NSError* error;
    // save to file
    
    [aString writeToURL:destinationPath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if(error){
        NSLog(@"==>%@", error);
        return false;
    }
    return true;
    
}

+ (BOOL)isVPNConnected
{
    NSDictionary *dict = CFBridgingRelease(CFNetworkCopySystemProxySettings());
    NSArray *keys = [dict[@"__SCOPED__"]allKeys];
    for (NSString *key in keys) {
        if ([key rangeOfString:@"tun"].location != NSNotFound){
            return YES;
        }
    }
    return NO;
}

+(NSString *)readStringFromFile:(NSString *)file_name{
    NSString *destinationPath = [[[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:[Util getAppGroup]] path] stringByAppendingPathComponent:file_name];
    
    return [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:destinationPath] encoding:NSUTF8StringEncoding];
}
+(NSArray *) getAllFileInPath{
    NSString *filePath = [[[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:[Util getAppGroup]] path];
    
    NSFileManager *manager = [NSFileManager defaultManager];
    NSArray *fileList = [manager contentsOfDirectoryAtPath:filePath
                                                     error:nil];
    //--- Listing file by name sort
    NSMutableArray *result = [[NSMutableArray alloc] init];
    for(int i =0; i < [fileList count]; i++){
        NSString *temp = fileList[i];
        if([temp containsString:@"ovpn"]){
            [result addObject:temp];
        }
    }
    
    NSLog(@"%@", result);
    return result;
}

+ (NSString *)getIPAddress {
    
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    
                }
                
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
    
}

+ (BOOL) pingToIP:(NSString *) ipDst{
    bool success = false;
    const char *host_name = [ipDst
                             cStringUsingEncoding:NSASCIIStringEncoding];
    
    SCNetworkReachabilityRef reachability = SCNetworkReachabilityCreateWithName(NULL,
                                                                                host_name);
    SCNetworkReachabilityFlags flags;
    success = SCNetworkReachabilityGetFlags(reachability, &flags);
    
    //prevents memory leak per Carlos Guzman's comment
    CFRelease(reachability);
    
    bool isAvailable = success && (flags & kSCNetworkFlagsReachable) &&
    !(flags & kSCNetworkFlagsConnectionRequired);
    if (isAvailable) {
        NSLog(@"Host is reachable: %d", flags);
    }else{
        NSLog(@"Host is unreachable");
    }
    return isAvailable;
}

+ (NSString *) getIPVPN{
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if( temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if ([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"utun1"])
                {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    NSLog(@"ifaName: %@, Address: %@",[NSString stringWithUTF8String:temp_addr->ifa_name],address);
                }
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    
    return address;
}
+ (UIColor *)colorWithHex:(UInt32)color andAlpha:(float)alpha
{
    unsigned char r, g, b;
    b = color & 0xFF;
    g = (color >> 8) & 0xFF;
    r = (color >> 16) & 0xFF;
    return [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:alpha];
}

+ (UIColor *)colorWithHexString:(NSString *)hexStr
{
    float alpha;
    NSString *newHexStr;
    NSCharacterSet *cSet = [NSCharacterSet characterSetWithCharactersInString:@"/-_,~^*&\\ "];
    if(![hexStr hasPrefix:@"#"]) hexStr = [NSString stringWithFormat:@"#%@", hexStr];
    if([hexStr rangeOfCharacterFromSet:cSet].location != NSNotFound) {
        
        NSScanner *scn = [NSScanner scannerWithString:hexStr];
        [scn scanUpToCharactersFromSet:cSet intoString:&newHexStr];
        alpha = [[[hexStr componentsSeparatedByCharactersInSet:cSet] lastObject] floatValue];
        
    } else {
        
        newHexStr = hexStr;
        alpha = 1.0f;
        
    }
    
    const char *cStr = [newHexStr cStringUsingEncoding:NSASCIIStringEncoding];
    long x = strtol(cStr+1, NULL, 16);
    return [self colorWithHex:x andAlpha:alpha];
}

+ (NSString *) getUUID:(NSString *) data1{
    NSData* data = [data1 dataUsingEncoding:NSUTF8StringEncoding];
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for (int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
    {
        [output appendFormat:@"%02x", digest[i]];
    }
    
    return output;
}

+ (NSString *) downOvpnByQrCode:(NSString *) wan_ip code:(NSString *) code username:(NSString *) user pwd:(NSString *) pass session:(NSString *) PHPSession{
    
    NSMutableURLRequest *urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@:8082/mobilevpn/mobileKey.php",wan_ip, nil]]];
    NSString *userUpdate =[NSString stringWithFormat:@"acct=%@&password=%@&authimage=%@",user,pass,code, nil];
    
    //create the Method "GET" or "POST"
    [urlRequest setHTTPMethod:@"POST"];
    
    //Convert the String to Data
    NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    [urlRequest setHTTPBody:data1];
    //NSString *cookie;
    //NSRange begin = [cookie rangeOfString:@"PHPSESSID"];
    //NSRange next = [cookie rangeOfString:@";"];
    //NSString *sub = [cookie substringWithRange:NSMakeRange(begin.location, next.location - begin.location)];
    //NSString *string1 = [cookie substringWithRange:NSMakeRange(@"Cookie: PHPSESSID".length, @"Cookie: PHPSESSID=39nt5tv9fjbnnav8ku8jul0e53".length)];
    [urlRequest setValue:PHPSession forHTTPHeaderField:@"cookie"];
    NSLog(@"%@", PHPSession);
    //NSURLSession *session = [NSURLSession sharedSession];
    static BOOL isComplete = false;
    NSURLSession *session = [NSURLSession sharedSession];
    __block NSString *ovpn = nil;
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        if(httpResponse.statusCode == 200)
        {
            NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"OVPN: %@",str);
            ovpn = str;
        }
        else
        {
            NSLog(@"Error");
        }
        isComplete = true;
    }];
    [dataTask resume];
    return ovpn;
    
}

+ (NSString *) getVPNProfileCurrentEdit{
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:[Util getAppGroup]];
    NSString *data = [defaults objectForKey:@"current_profile_edit"];
    return data;
}

+ (void) setVPNProfileCurrentEdit:(NSString *) fileName{
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:[Util getAppGroup]];
    [defaults setObject:fileName forKey:@"current_profile_edit"];
}

+ (void) deleteVPNProfileCurrentEdit{
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:[Util getAppGroup]];
    [defaults removeObjectForKey:@"current_profile_edit"];

}

@end
