//
//  MoviesTableViewController.m
//  CustomizingTableViewCell


#import "ChoXuLyController.h"
#import "ChoXuLyTableViewCell.h"
#import "ObjectBDS.h"
#import "Util.h"
#import <Foundation/Foundation.h>
#import "LoginController.h"
#import "ConnectController.h"

@interface ChoXuLyController ()
@property (weak, nonatomic) IBOutlet UILabel *viewChooseServer;
@end

@implementation ChoXuLyController

NSMutableArray *marrArray;
NSString *cellIdentifier = @"ChoXuLyTableCell";
NSMutableArray *arrayOBJSelected;

static NSString* hostname, * nameserver;

+ (NSString *) getHostname{
    return hostname;
}

+ (NSString *) getnameserver{
    return nameserver;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    arrayOBJSelected = [[NSMutableArray alloc] init];
    marrArray = [[NSMutableArray alloc] init];
    
    //ObjectBDS *movie = [[ObjectBDS alloc] init];
    
    // show dialog
    
    NSError *err = nil;
    //NSDictionary *parsedObject = [NSJSONSerialization JSONObjectWithData:[[self getAllServer] dataUsingEncoding:NSUTF8StringEncoding] options:0 error:&err];
    
    ObjectBDS *obj = [ConnectController getObject];
    //obj.nameserver = [parsedObject valueForKey:@"nameserver"];
    //obj.idserver = [parsedObject valueForKey:@"idserver"];
    //obj.hostname = [parsedObject valueForKey:@"hostname"];
    
    hostname = obj.hostname;
    nameserver = obj.nameserver;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [array addObject:obj];
    
    marrArray = array;
    
    _viewChooseServer.backgroundColor = [Util colorWithHexString:@"#7FD78B"];
    
}

- (NSString *) getAllServer{
    NSDictionary *headers = @{ @"content-type": @"application/x-www-form-urlencoded" };
       NSString *strServer = [NSString stringWithFormat:@"idserver=%@", [LoginController getChooseServer]];
    NSMutableData *postData = [[NSMutableData alloc] initWithData:[strServer dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://vpn.fixpc.best/vpnbackend/test/Api/getOCSVpnServer"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    
    __block NSString *dateResA = nil;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                        dateResA = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                        NSLog(@"%@", dateResA);
                                                    }
                                                }];
    [dataTask resume];
    while (!dateResA) {
        sleep(1);
    }
    return dateResA;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*if([tableView cellForRowAtIndexPath:indexPath].accessoryType == UITableViewCellAccessoryCheckmark){
        [tableView cellForRowAtIndexPath:indexPath].accessoryType = UITableViewCellAccessoryNone;
        [arrayOBJSelected removeObject:marrArray[indexPath.row]];
        
    }else{
        [tableView cellForRowAtIndexPath:indexPath].accessoryType = UITableViewCellAccessoryCheckmark;
        [arrayOBJSelected addObject:marrArray[indexPath.row]];
    }
     */
    //ConnectController *gotoYourClass = [self.storyboard instantiateViewControllerWithIdentifier:@"connect"];
    //[self.navigationController pushViewController:gotoYourClass animated:YES];
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
#pragma mark - For Tap back
- (void) tapBack{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [marrArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChoXuLyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    ObjectBDS *movie = (marrArray)[indexPath.row];
    
    cell.nameServer.text = movie.nameserver;
    return cell;
}

@end
