//
//  ChildDNSViewController.m
//  eVPN
//
//  Created by CYTECH on 7/11/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import "ChildDNSViewController.h"
#import "Util.h"

NS_ENUM(NSInteger, DropdownComponentsDNS) {
    DropdownComponentShape = 0,
    DropdownComponentColor,
    DropdownComponentLineWidth,
    DropdownComponentsCount
};
@interface ChildDNSViewController ()
@property (strong, nonatomic) NSArray<NSString *> *componentTitlesPort;
@property (strong, nonatomic) NSArray<NSString *> *shapeTitlesPort;
@end

@implementation ChildDNSViewController
NSMutableArray *arrayDNS;
static int dnsChoose;
+ (int) getdnsChoose{
    return dnsChoose;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dropdownMenu.layer.borderColor = [[UIColor grayColor] CGColor];
    
    self.view.layer.cornerRadius = 3;
    self.dropdownMenu.layer.cornerRadius = 3;
    self.dropdownMenu.selectedComponentBackgroundColor = [Util colorWithHexString:@"#0099CC"];
    self.dropdownMenu.dropdownBackgroundColor = [Util colorWithHexString:@"#00AEFF"];
    
    self.dropdownMenu.dropdownShowsTopRowSeparator = NO;
    self.dropdownMenu.dropdownShowsBottomRowSeparator = NO;
    self.dropdownMenu.dropdownShowsBorder = NO;
    self.dropdownMenu.tintColor = [UIColor whiteColor];
    
    self.dropdownMenu.backgroundDimmingOpacity = 0.05;
    
    // auto is server
    self.dropdownMenu.backgroundColor = [Util colorWithHexString:@"#0099CC"];
    
    arrayDNS = [[NSMutableArray alloc] init];
    [arrayDNS addObject:@"e-VPN (AD Block/SmartDNS)"];
    [arrayDNS addObject:@"Google"];
    [arrayDNS addObject:@"OpenDNS"];
    [arrayDNS addObject:@"Cloudflare"];
    self.shapeTitlesPort = arrayDNS;
    
    self.componentTitlesPort = @[arrayDNS[0]];
    
    NSUserDefaults *myDefaults = [[NSUserDefaults alloc]
                                  initWithSuiteName:[Util getAppGroup]];
    
    NSString *dns = [myDefaults stringForKey:@"dns"];
    if(dns != nil){
        self.componentTitlesPort = @[arrayDNS[[dns intValue]]];
        dnsChoose = [dns intValue];
    }else{
        dnsChoose = 0; // UDP
        [myDefaults setObject:@"0" forKey:@"dns"];
        [myDefaults synchronize];
    }
    
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_data) name:@"close_dropdown" object:nil];
}

#pragma mark - MKDropdownMenuDataSource

- (NSInteger)numberOfComponentsInDropdownMenu:(MKDropdownMenu *)dropdownMenu {
    return DropdownComponentsCount;
}

- (NSInteger)dropdownMenu:(MKDropdownMenu *)dropdownMenu numberOfRowsInComponent:(NSInteger)component {
    switch (component) {
        case DropdownComponentShape:
            return self.shapeTitlesPort.count;
        default:
            return 0;
    }
}

#pragma mark - MKDropdownMenuDelegate

- (CGFloat)dropdownMenu:(MKDropdownMenu *)dropdownMenu rowHeightForComponent:(NSInteger)component {
    if (component == DropdownComponentColor) {
        return 20;
    }
    return 0; // use default row height
}

- (CGFloat)dropdownMenu:(MKDropdownMenu *)dropdownMenu widthForComponent:(NSInteger)component {
    if (component == DropdownComponentShape || component == DropdownComponentLineWidth) {
        return MAX(dropdownMenu.bounds.size.width/2, 125);
    }
    return 0; // use automatic width
}

- (BOOL)dropdownMenu:(MKDropdownMenu *)dropdownMenu shouldUseFullRowWidthForComponent:(NSInteger)component {
    return NO;
}

- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForComponent:(NSInteger)component {
    if ( [(NSString*)[UIDevice currentDevice].model hasPrefix:@"iPad"] ) {
        return [[NSAttributedString alloc] initWithString:self.componentTitlesPort[component]
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:24 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor whiteColor]}];
    }
    
    return [[NSAttributedString alloc] initWithString:self.componentTitlesPort[component]
                                           attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                        NSForegroundColorAttributeName: [UIColor whiteColor]}];
}

- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForSelectedComponent:(NSInteger)component {
    
    if ( [(NSString*)[UIDevice currentDevice].model hasPrefix:@"iPad"] ) {
        return [[NSAttributedString alloc] initWithString:self.componentTitlesPort[component]
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:24 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor whiteColor]}];
    }
    return [[NSAttributedString alloc] initWithString:self.componentTitlesPort[component]
                                           attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightRegular],
                                                        NSForegroundColorAttributeName: self.view.tintColor}];
    
}

- (UIView *)dropdownMenu:(MKDropdownMenu *)dropdownMenu viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    switch (component) {
        case DropdownComponentShape: {
            ShapeSelectView *shapeSelectView = (ShapeSelectView *)view;
            if (shapeSelectView == nil || ![shapeSelectView isKindOfClass:[ShapeSelectView class]]) {
                shapeSelectView = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([ShapeSelectView class]) owner:nil options:nil] firstObject];
            }
            shapeSelectView.shapeView.sidesCount = row + 2;
            shapeSelectView.textLabel.text = self.shapeTitlesPort[row];
            shapeSelectView.selected = (shapeSelectView.shapeView.sidesCount == self.shapeView.sidesCount);
            return shapeSelectView;
        }
        default:
            return nil;
    }
}

- (UIColor *)dropdownMenu:(MKDropdownMenu *)dropdownMenu backgroundColorForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == DropdownComponentColor) {
        return [self colorForRow:row];
    }
    return nil;
}

- (void)dropdownMenu:(MKDropdownMenu *)dropdownMenu didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    switch (component) {
        case DropdownComponentShape:
        {
            self.shapeView.sidesCount = row + 2;
            self.componentTitlesPort = @[arrayDNS[row]];
            
            dnsChoose = row;
            NSUserDefaults *myDefaults = [[NSUserDefaults alloc]
                                          initWithSuiteName:[Util getAppGroup]];
            NSString *str = [NSString stringWithFormat:@"%ld", (long)row];
            [myDefaults setObject:str forKey:@"dns"];
            [myDefaults synchronize];
            
            [dropdownMenu reloadComponent:component];
            [dropdownMenu closeAllComponentsAnimated:true];
            break;
        }
        default:
            break;
    }
}

#pragma mark - Utility

- (UIColor *)colorForRow:(NSInteger)row {
    return [UIColor colorWithHue:(CGFloat)row/[self.dropdownMenu numberOfRowsInComponent:DropdownComponentColor]
                      saturation:1.0
                      brightness:1.0
                           alpha:1.0];
}
-(void)handle_data {
    [_dropdownMenu closeAllComponentsAnimated:true];
}

@end
