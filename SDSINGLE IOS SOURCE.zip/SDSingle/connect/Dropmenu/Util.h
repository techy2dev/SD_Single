//
//  Util.h
//  NETExtension
//
//  Created by CYTECH on 7/1/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Util : NSObject
+ (NSString *) getAppGroup;
+ (BOOL) writeStringToFile:(NSString *)aString name_file:(NSString *) file_name;
    +(NSString *)readStringFromFile:(NSString *)file_name;
    +(NSArray *) getAllFileInPath;
+ (UIColor *) colorWithHexString:(NSString *)hexStr;
+ (NSString *) getUUID:(NSString *) data;
+ (NSString *) downOvpnByQrCode:(NSString *) wan_ip code:(NSString *) code username:(NSString *) user pwd:(NSString *) pass session:(NSString *) PHPSession;
+ (void) setVPNProfileCurrentEdit:(NSString *) fileName;
+ (NSString *) getVPNProfileCurrentEdit;
+ (void) deleteVPNProfileCurrentEdit;
+ (Boolean) removeVPNProfile:(NSString *) fileName;
+ (NSString *) getNEBundleId;
+ (BOOL)isVPNConnected;
+ (NSString *)getIPAddress;
+ (NSString *) getIPVPN;
+ (BOOL) pingToIP:(NSString *) ipDst;
+ (NSString *) getCurrentReachabilit;
+ (NSString *) getDataFrom:(NSString *)url;
+ (NSString *) getDataFrom:(NSString *)url username:(NSString *) user password:(NSString *)pass;

@end
