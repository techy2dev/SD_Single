//
//  ChildPortViewController.h
//  eVPN
//
//  Created by CYTECH on 7/11/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MKDropdownMenu.h"
#import "ShapeView.h"
#import "ShapeSelectView.h"
NS_ASSUME_NONNULL_BEGIN

@interface ChildPortViewController : UIViewController <MKDropdownMenuDataSource, MKDropdownMenuDelegate>
@property (weak, nonatomic) IBOutlet MKDropdownMenu *dropdownMenu;
@property (weak, nonatomic) IBOutlet ShapeView *shapeView;

+ (int) getPortChoose;
@end

NS_ASSUME_NONNULL_END
