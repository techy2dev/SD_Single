//
//  ChildEncrytionViewController.m
//  eVPN
//
//  Created by CYTECH on 7/11/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import "ChildEncrytionViewController.h"
#import "Util.h"

NS_ENUM(NSInteger, DropdownComponentsEncryption) {
    DropdownComponentShape = 0,
    DropdownComponentColor,
    DropdownComponentLineWidth,
    DropdownComponentsCount
};
@interface ChildEncrytionViewController ()
@property (strong, nonatomic) NSArray<NSString *> *componentTitlesEncryption;
@property (strong, nonatomic) NSArray<NSString *> *shapeTitlesEncryption;
@end

@implementation ChildEncrytionViewController
NSMutableArray *arrayEncryption;
static int encryptionChoose;
+ (int) getEncryptionChoose{
    return encryptionChoose;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.dropdownMenu.layer.borderColor = [[UIColor grayColor] CGColor];
    
    self.view.layer.cornerRadius = 3;
    self.dropdownMenu.layer.cornerRadius = 3;
    self.dropdownMenu.selectedComponentBackgroundColor = [Util colorWithHexString:@"#0099CC"];
    self.dropdownMenu.dropdownBackgroundColor = [Util colorWithHexString:@"#00AEFF"];
    
    self.dropdownMenu.dropdownShowsTopRowSeparator = NO;
    self.dropdownMenu.dropdownShowsBottomRowSeparator = NO;
    self.dropdownMenu.dropdownShowsBorder = NO;
    self.dropdownMenu.tintColor = [UIColor whiteColor];
    
    self.dropdownMenu.backgroundDimmingOpacity = 0.05;
    
    // auto is server
    self.dropdownMenu.backgroundColor = [Util colorWithHexString:@"#0099CC"];
    
    arrayEncryption = [[NSMutableArray alloc] init];
    [arrayEncryption addObject:@"AES-128-GCM"];
    [arrayEncryption addObject:@"AES-256-GCM"];
    [arrayEncryption addObject:@"AES-128-CBC"];
    [arrayEncryption addObject:@"AES-256-CBC"];
    
    self.shapeTitlesEncryption= arrayEncryption;
    
    self.componentTitlesEncryption = @[arrayEncryption[0]];
    
    NSUserDefaults *myDefaults = [[NSUserDefaults alloc]
                                  initWithSuiteName:[Util getAppGroup]];
    
    NSString *dns = [myDefaults stringForKey:@"encryption"];
    if(dns != nil){
        self.componentTitlesEncryption = @[arrayEncryption[[dns intValue]]];
        encryptionChoose = [dns intValue];
    }else{
        encryptionChoose = 0; // UDP
        [myDefaults setObject:@"0" forKey:@"encryption"];
        [myDefaults synchronize];
    }
    
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_data) name:@"close_dropdown" object:nil];
}

#pragma mark - MKDropdownMenuDataSource

- (NSInteger)numberOfComponentsInDropdownMenu:(MKDropdownMenu *)dropdownMenu {
    return DropdownComponentsCount;
}

- (NSInteger)dropdownMenu:(MKDropdownMenu *)dropdownMenu numberOfRowsInComponent:(NSInteger)component {
    switch (component) {
        case DropdownComponentShape:
            return self.shapeTitlesEncryption.count;
        default:
            return 0;
    }
}

#pragma mark - MKDropdownMenuDelegate

- (CGFloat)dropdownMenu:(MKDropdownMenu *)dropdownMenu rowHeightForComponent:(NSInteger)component {
    if (component == DropdownComponentColor) {
        return 20;
    }
    return 0; // use default row height
}

- (CGFloat)dropdownMenu:(MKDropdownMenu *)dropdownMenu widthForComponent:(NSInteger)component {
    if (component == DropdownComponentShape || component == DropdownComponentLineWidth) {
        return MAX(dropdownMenu.bounds.size.width/2, 125);
    }
    return 0; // use automatic width
}

- (BOOL)dropdownMenu:(MKDropdownMenu *)dropdownMenu shouldUseFullRowWidthForComponent:(NSInteger)component {
    return NO;
}

- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForComponent:(NSInteger)component {
    if ( [(NSString*)[UIDevice currentDevice].model hasPrefix:@"iPad"] ) {
        return [[NSAttributedString alloc] initWithString:self.componentTitlesEncryption[component]
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:24 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor whiteColor]}];
    }
    
    return [[NSAttributedString alloc] initWithString:self.componentTitlesEncryption[component]
                                           attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                        NSForegroundColorAttributeName: [UIColor whiteColor]}];
}

- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForSelectedComponent:(NSInteger)component {
    
    if ( [(NSString*)[UIDevice currentDevice].model hasPrefix:@"iPad"] ) {
        return [[NSAttributedString alloc] initWithString:self.componentTitlesEncryption[component]
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:24 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor whiteColor]}];
    }
    return [[NSAttributedString alloc] initWithString:self.componentTitlesEncryption[component]
                                           attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightRegular],
                                                        NSForegroundColorAttributeName: self.view.tintColor}];
    
}

- (UIView *)dropdownMenu:(MKDropdownMenu *)dropdownMenu viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    switch (component) {
        case DropdownComponentShape: {
            ShapeSelectView *shapeSelectView = (ShapeSelectView *)view;
            if (shapeSelectView == nil || ![shapeSelectView isKindOfClass:[ShapeSelectView class]]) {
                shapeSelectView = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([ShapeSelectView class]) owner:nil options:nil] firstObject];
            }
            shapeSelectView.shapeView.sidesCount = row + 2;
            shapeSelectView.textLabel.text = self.shapeTitlesEncryption[row];
            shapeSelectView.selected = (shapeSelectView.shapeView.sidesCount == self.shapeView.sidesCount);
            return shapeSelectView;
        }
        default:
            return nil;
    }
}

- (UIColor *)dropdownMenu:(MKDropdownMenu *)dropdownMenu backgroundColorForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == DropdownComponentColor) {
        return [self colorForRow:row];
    }
    return nil;
}

- (void)dropdownMenu:(MKDropdownMenu *)dropdownMenu didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    switch (component) {
        case DropdownComponentShape:
        {
            self.shapeView.sidesCount = row + 2;
            self.componentTitlesEncryption = @[arrayEncryption[row]];
            encryptionChoose = row;
            NSUserDefaults *myDefaults = [[NSUserDefaults alloc]
                                          initWithSuiteName:[Util getAppGroup]];
            NSString *str = [NSString stringWithFormat:@"%ld", (long)row];
            [myDefaults setObject:str forKey:@"encryption"];
            [myDefaults synchronize];
            
            [dropdownMenu reloadComponent:component];
            [dropdownMenu closeAllComponentsAnimated:true];
            break;
        }
        default:
            break;
    }
}

#pragma mark - Utility

- (UIColor *)colorForRow:(NSInteger)row {
    return [UIColor colorWithHue:(CGFloat)row/[self.dropdownMenu numberOfRowsInComponent:DropdownComponentColor]
                      saturation:1.0
                      brightness:1.0
                           alpha:1.0];
}
-(void)handle_data {
    [_dropdownMenu closeAllComponentsAnimated:true];
}
@end
