//
//  Movie.m
//  CustomizingTableViewCell
//
//  Created by abc on 28/01/15.
//  Copyright (c) 2015 com.ms. All rights reserved.
//

#import "ObjectBDS.h"

@implementation ObjectBDS

@synthesize config, idserver, nameserver, hostname, bash, location, price, openssh;

@end
