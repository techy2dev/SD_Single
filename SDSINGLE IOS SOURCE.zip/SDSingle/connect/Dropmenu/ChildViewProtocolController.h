//
//  ChildViewProtocolController.h
//  NETExtension
//
//  Created by CYTECH on 5/2/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MKDropdownMenu.h"
#import "ShapeView.h"
#import "ShapeSelectView.h"
@interface ChildViewProtocolController :  UIViewController <MKDropdownMenuDataSource, MKDropdownMenuDelegate>
@property (weak, nonatomic) IBOutlet MKDropdownMenu *dropdownMenu;

@property (weak, nonatomic) IBOutlet ShapeView *shapeView;

+ (int) getIndexServerChoose;
+ (NSDictionary *) getAllServer;
@end
