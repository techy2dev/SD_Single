//
//  LoginController.m
//  AladdinVPN
//
//  Created by CYTECH on 8/27/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import "LoginController.h"
#import "Util.h"
#import "ChoXuLyController.h"
#import "ConnectController.h"
#import <Foundation/Foundation.h>
@interface LoginController ()
@property (weak, nonatomic) IBOutlet UITextField *tfUserName;
@property (weak, nonatomic) IBOutlet UITextField *tfPassword;
@property (weak, nonatomic) IBOutlet UIButton *viewLogin;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;


@end

@implementation LoginController
static NSString *idServer;
static NSString *uservpn, *passvpn;
static NSString *expiredate, *days;

+ (NSString *) getDays{
    return days;
}

+ (NSString *) getExpiredate
{
    return expiredate;
}

+ (NSString *) getChooseServer{
    return idServer;
}

+ (NSString *) getUserVPN{
    return uservpn;
}

+ (NSString *) getPassVPN{
    return passvpn;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _viewLogin.layer.cornerRadius = 20;
    _tfUserName.delegate = self;
    _tfPassword.delegate = self;
    _tfPassword.secureTextEntry = YES;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *username = [prefs stringForKey:@"username"];
    [_tfUserName setText:username];
   
    NSString *password = [prefs stringForKey:@"password"];
    [_tfPassword setText:password];
    
    _tfPassword.textAlignment = NSTextAlignmentCenter;
    _tfUserName.textAlignment = NSTextAlignmentCenter;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
  
    [self.view addGestureRecognizer:tap];
    _indicator.hidden = true;
    
    // We don't need login and redirect to the main screen
    ConnectController *gotoYourClass = [self.storyboard instantiateViewControllerWithIdentifier:@"connect"];
    [self.navigationController pushViewController:gotoYourClass animated:YES];
    
}
- (IBAction)btnLogin:(id)sender {
    
    NSString *username = _tfUserName.text;
    NSString *password = _tfPassword.text;
    
    if(![username isEqualToString:@""] && ![password isEqualToString:@""]){
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        [prefs setObject:username forKey:@"username"];
        [prefs setObject:password forKey:@"password"];
        [prefs synchronize];
        [self loginIn:username pass:password];
    }else{
       
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Notification"
                                     message:@"Please enter username/password!"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        //Add Buttons<div jsname="B34EJ" class="dEOOab RxsGPe __web-inspector-hide-shortcut__" aria-atomic="true" aria-live="assertive">.</div>
        UIAlertAction* noButton = [UIAlertAction
                                   actionWithTitle:@"YES"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       //Handle no, thanks button
                                   }];
        
        [alert addAction:noButton];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
-(void)dismissKeyboard
{
    [_tfPassword resignFirstResponder];
    [_tfUserName resignFirstResponder];
}
- (void) loginIn: (NSString *) user pass:(NSString *) pass{
    
    
    _indicator.hidden = false;
    [_indicator startAnimating];
    _indicator.transform = CGAffineTransformMakeScale(2, 2);
    NSDictionary *headers = @{ @"content-type": @"application/x-www-form-urlencoded"};
    
    
    NSString *strUser = [NSString stringWithFormat:@"username=%@", user];
    NSString *strPass = [NSString stringWithFormat:@"&password=%@", pass];
    NSMutableData *postData = [[NSMutableData alloc] initWithData:[strUser dataUsingEncoding:NSUTF8StringEncoding]];
    [postData appendData:[strPass dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://sendflexi.com/Api/verify"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    __block NSString *dateResA = nil;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        // This block will be executed asynchronously on the main thread.
                                                        [_indicator stopAnimating];
                                                        _indicator.hidden = true;
                                                   
                                                  
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                    } else {
                                                         dateResA = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                                        NSLog(@"%@", dateResA);
                                                        
                                                        // login
                                                        NSError *err = nil;
                                                        NSDictionary *parsedObject = [NSJSONSerialization JSONObjectWithData:[dateResA dataUsingEncoding:NSUTF8StringEncoding] options:0 error:&err];
                                                        
                                                        NSString *serverId = [parsedObject valueForKey:@"id"];
                                                        
                                                        if (serverId != nil) {
                                                            idServer = serverId;
                                                            uservpn = [parsedObject valueForKey:@"username"];
                                                            passvpn = [parsedObject valueForKey:@"password"];
                                                            expiredate = [parsedObject valueForKey:@"expired_on"];
                                                            days = [parsedObject valueForKey:@"days"];
                                                          
                                                            // open choose server
                                                            //ChoXuLyController *gotoYourClass = [self.storyboard instantiateViewControllerWithIdentifier:@"choose"];
                                                            //[self.navigationController pushViewController:gotoYourClass animated:YES];
                                                            ConnectController *gotoYourClass = [self.storyboard instantiateViewControllerWithIdentifier:@"connect"];
                                                            [self.navigationController pushViewController:gotoYourClass animated:YES];
                                                            
                                                            
                                                        } else {
                                                           
                                                            UIAlertController * alert = [UIAlertController
                                                                                         alertControllerWithTitle:@"Login"
                                                                                         message:@"Wrong username or password"
                                                                                         preferredStyle:UIAlertControllerStyleAlert];
                                                            
                                                            //Add Buttons
                                                            
                                                            UIAlertAction* yesButton = [UIAlertAction
                                                                                        actionWithTitle:@"Yes"
                                                                                        style:UIAlertActionStyleDefault
                                                                                        handler:^(UIAlertAction * action) {
                                                                                            //Handle your yes please button action here
                                                                                            //[self clearAllData];
                                                                                        }];
                                                            
                                                            //Add your buttons to alert controller
                                                            
                                                            [alert addAction:yesButton];
                                                            
                                                            [self presentViewController:alert animated:YES completion:nil];
                                                        }
                                                        
                                                    }
                                                });
                                                }];
    [dataTask resume];
   /* while (!dateResA) {
        sleep(1);
    }
    */
}

@end
