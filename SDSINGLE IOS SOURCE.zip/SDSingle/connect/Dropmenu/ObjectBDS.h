//
//  Movie.h
//  CustomizingTableViewCell
//
//  Created by abc on 28/01/15.
//  Copyright (c) 2015 com.ms. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectBDS : NSObject
@property (nonatomic, copy) NSNumber *idserver;
@property (nonatomic, copy) NSString *nameserver;
@property (nonatomic, copy) NSString *hostname;
@property (nonatomic, copy) NSString *bash;
@property (nonatomic, copy) NSString *location;
@property (nonatomic, copy) NSString *isp;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *openssh;
@property (nonatomic, copy) NSString *dropbear;
@property (nonatomic, copy) NSString *config;
@end
