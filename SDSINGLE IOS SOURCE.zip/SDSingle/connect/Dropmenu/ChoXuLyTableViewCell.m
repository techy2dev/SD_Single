//
//  MoviesTableViewCell.m
//  CustomizingTableViewCell
//
//  Created by abc on 28/01/15.
//  Copyright (c) 2015 com.ms. All rights reserved.
//

#import "ChoXuLyTableViewCell.h"
#import "ChoXuLyController.h"

@implementation ChoXuLyTableViewCell
@synthesize nameServer;

bool checked = false;

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
   
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
   // [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
    //self.lblTitle.text = @"ABCBA";
}

@end
