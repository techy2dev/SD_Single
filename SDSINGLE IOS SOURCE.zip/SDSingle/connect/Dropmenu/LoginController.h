//
//  LoginController.h
//  AladdinVPN
//
//  Created by CYTECH on 8/27/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginController : UIViewController
+ (NSString *) getChooseServer;
+ (NSString *) getUserVPN;
+ (NSString *) getDays;
+ (NSString *) getExpiredate;
+ (NSString *) getPassVPN;
@end

NS_ASSUME_NONNULL_END
