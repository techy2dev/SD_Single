//
//  ConnectController.m
//  AladdinVPN
//
//  Created by CYTECH on 8/27/19.
//  Copyright © 2019 Chi Yu Lan All rights reserved.
//

#import "ConnectController.h"
#import "LoginController.h"
#import "ChoXuLyController.h"
#import <NetworkExtension/NETunnelProviderManager.h>
#import <NetworkExtension/NETunnelProviderProtocol.h>
#import <NetworkExtension/NEVPNConnection.h>
#import "Util.h"

@import FirebaseDatabase;

@interface ConnectController ()

@property (weak, nonatomic) IBOutlet UIButton *viewConnect;
@property (weak, nonatomic) IBOutlet UIImageView *viewImgChooseServer;
@property (weak, nonatomic) IBOutlet UILabel *lbServerName;
@property (weak, nonatomic) IBOutlet UIButton *uibtn;
@property (weak, nonatomic) IBOutlet UILabel *statusConnect;
@property (weak, nonatomic) IBOutlet UIView *viewConnected;
@property (weak, nonatomic) IBOutlet UIView *imgConnected;
@property (weak, nonatomic) IBOutlet UILabel *lbStatusConnected;
@property (weak, nonatomic) IBOutlet UILabel *lbCountTime;
@property (weak, nonatomic) IBOutlet UILabel *daysLeft;
@property (weak, nonatomic) IBOutlet UITextField *txtPinInput;
@property (weak, nonatomic) IBOutlet UIView *viewPinPanel;
@property (weak, nonatomic) IBOutlet UIButton *btnShowHidePassword;
@property (weak, nonatomic) IBOutlet UIButton *etisalatBtn;
@property (weak, nonatomic) IBOutlet UIButton *duBtn;




@property (strong, nonatomic) FIRDatabaseReference *ref;

@end

@implementation ConnectController{
    __block NETunnelProviderManager * vpnManager;
}
static bool isOpenMainController = false;
Boolean isConnect = false;

static Boolean getServerListInFireBase = true;
Boolean isServerListLoaded = false;
NSArray* serverList = nil;
NSArray* proxyServerList = nil;

Boolean isForEtisalat = true;

UIColor *colorGreen;
UIColor *colorRed;
UIColor *colorGrey;

static ObjectBDS *obj;
+ (ObjectBDS *) getObject{
    return obj;
}

- (void) hiddeConnected{
    
}
-(void) viewDidAppear:(BOOL)animated{
    _uibtn.enabled = YES;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *varyingString1 = @"Expiry Date :";
    NSString *varyingString2 = @"---- / -- / --";
    NSString *str = [NSString stringWithFormat: @"%@ %@", varyingString1, varyingString2];
    _daysLeft.text = str;
    
    [self hiddeConnected];
    
    // Define the colors
    colorGreen = [UIColor colorWithRed:76.0f/255.0f green:176.0f/255.0f blue:80.0f/255.0f alpha:1.0f];
    colorRed = [UIColor colorWithRed:254.0f/255.0f green:23.0f/255.0f blue:67.0f/255.0f alpha:1.0f];
    colorGrey = [UIColor colorWithRed:105.0f/255.0f green:105.0f/255.0f blue:103.0f/255.0f alpha:1.0f];
    
    // Make View and Buttons Corner Radius
    _viewPinPanel.layer.borderColor = colorGreen.CGColor;
    _viewPinPanel.layer.cornerRadius = 22.5;
    _viewPinPanel.layer.borderWidth = 2;
    _viewPinPanel.layer.zPosition = -1;
    
    // Channel Options
    //_etisalatBtn.layer.cornerRadius = 22.5;
    CAShapeLayer * maskLayer1 = [CAShapeLayer layer];
    maskLayer1.path = [UIBezierPath bezierPathWithRoundedRect: _etisalatBtn.bounds byRoundingCorners: UIRectCornerTopLeft | UIRectCornerBottomLeft cornerRadii: (CGSize){22.5, 22.5}].CGPath;
    _etisalatBtn.layer.mask = maskLayer1;
    
    //_duBtn.layer.cornerRadius = 22.5;
    CAShapeLayer * maskLayer2 = [CAShapeLayer layer];
    maskLayer2.path = [UIBezierPath bezierPathWithRoundedRect: _duBtn.bounds byRoundingCorners: UIRectCornerTopRight | UIRectCornerBottomRight cornerRadii: (CGSize){22.5, 22.5}].CGPath;
    _duBtn.layer.mask = maskLayer2;
    
    // Connect Button
    _uibtn.layer.cornerRadius = 22.5;
    
    // Keyboard Hide Gesture
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    // restore pin code from registry
    _txtPinInput.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"pin_code"];
    
    
    // Configure Server List
    if (getServerListInFireBase) {
        // Load Server List
        self.ref = [[FIRDatabase database] reference];
        [_ref observeSingleEventOfType:FIRDataEventTypeValue withBlock:^(FIRDataSnapshot * _Nonnull snapshot) {
            NSDictionary *serverDic = snapshot.value;
            
            
            NSDictionary *wifiServerDic = [serverDic objectForKey:@"Etisalat_Servers"];
            NSDictionary *duServerDic = [serverDic objectForKey:@"DU_Servers"];
            
            if (wifiServerDic != nil) {
                serverList = wifiServerDic.allValues;
            }
            
            if (duServerDic != nil) {
                proxyServerList = duServerDic.allValues;
            }
            
            isServerListLoaded = true;
            //NSLog(@"%@", serverList);
        }];
    } else {
        serverList = [NSArray arrayWithObjects:@"95.217.16.184"
                      , @"95.217.213.120"
                      , @"78.47.72.205"
                      , @"78.47.72.254"
                      , @"78.47.72.213"
                      , @"78.47.74.174"
                      , @"78.46.252.164"
                      , @"78.46.248.131"
                      , @"49.12.106.112"
                      , @"49.12.109.202"
                      , @"49.12.96.124"
                      , @"49.12.111.24"
                      , @"103.95.27.14", nil];
        
        // Configure Proxy Server List
        proxyServerList = [NSArray arrayWithObjects:@"95.216.221.196", @"95.217.166.77", @"95.217.166.191", nil];
        
        isServerListLoaded = true;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self.view endEditing:true];
    
    [_uibtn endEditing:false];
    [_uibtn setNeedsFocusUpdate];
    
    return YES;
}

-(void)dismissKeyboard
{
    [_txtPinInput resignFirstResponder];
}


- (IBAction)btnShowHidePassword:(id)sender {
    if (_txtPinInput.secureTextEntry) {
        _txtPinInput.secureTextEntry = false;
        UIImage *image = [[UIImage imageNamed:@"password"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [_btnShowHidePassword setImage:image forState:UIControlStateNormal];
        _btnShowHidePassword.tintColor = colorRed;
    } else {
        _txtPinInput.secureTextEntry = true;
        UIImage *image = [[UIImage imageNamed:@"password"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [_btnShowHidePassword setImage:image forState:UIControlStateNormal];
        _btnShowHidePassword.tintColor = colorGrey;
    }
}

- (IBAction)btnEtisalat:(id)sender {
    isForEtisalat = true;
    _etisalatBtn.backgroundColor = colorGreen;
    _duBtn.backgroundColor = colorGrey;
}

- (IBAction)btnDU:(id)sender {
    isForEtisalat = false;
    _etisalatBtn.backgroundColor = colorGrey;
    _duBtn.backgroundColor = colorGreen;
}


- (IBAction)btnConnect:(id)sender {
    
    [self dismissKeyboard];
    
    isOpenMainController = false;
    if(isConnect) {
        isConnect = false;
        [vpnManager.connection stopVPNTunnel];
        //[_uibtn setTitle:@"CONNECT" forState:UIControlStateNormal];
        _uibtn.enabled = YES;
    } else {
        //[_uibtn setTitle:@"CONNECTING" forState:UIControlStateNormal];
        
        // Check PIN Code
        NSString *pinCode = _txtPinInput.text;
        
        if([pinCode isEqualToString:@""]){
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Notification"
                                         message:@"Please enter PIN Code!"
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* noButton = [UIAlertAction
                                       actionWithTitle:@"YES"
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction * action) {
                //Handle no, thanks button
            }];
            
            [alert addAction:noButton];
            
            [self presentViewController:alert animated:YES completion:nil];
        } else {
            
            if (!isServerListLoaded) {
                UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:@"Notification"
                                             message:@"Please wait a moment while loading server list"
                                             preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* noButton = [UIAlertAction
                                           actionWithTitle:@"YES"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                    //Handle no, thanks button
                }];
                
                [alert addAction:noButton];
                
                [self presentViewController:alert animated:YES completion:nil];
                
                return;
            }
            
            if (isForEtisalat) {
                if (serverList == nil || serverList.count == 0 ) {
                    // Check Server List
                    UIAlertController * alert = [UIAlertController
                                                 alertControllerWithTitle:@"Notification"
                                                 message:@"No Etisalat Server Information."
                                                 preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* noButton = [UIAlertAction
                                               actionWithTitle:@"Ok"
                                               style:UIAlertActionStyleDefault
                                               handler:^(UIAlertAction * action) {
                        //Handle no, thanks button
                    }];
                    
                    [alert addAction:noButton];
                    
                    [self presentViewController:alert animated:YES completion:nil];
                    
                    return;
                }
            } else {
                if (proxyServerList == nil || proxyServerList.count == 0 ) {
                    // Check Server List
                    UIAlertController * alert = [UIAlertController
                                                 alertControllerWithTitle:@"Notification"
                                                 message:@"No DU Server Information."
                                                 preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* noButton = [UIAlertAction
                                               actionWithTitle:@"Ok"
                                               style:UIAlertActionStyleDefault
                                               handler:^(UIAlertAction * action) {
                        //Handle no, thanks button
                    }];
                    
                    [alert addAction:noButton];
                    
                    [self presentViewController:alert animated:YES completion:nil];
                    
                    return;
                }
            }
            
            // Disable Buttons
            _uibtn.enabled = NO;
            _etisalatBtn.enabled = NO;
            _duBtn.enabled = NO;
            
            [self initVPNTunnelProviderManager:pinCode];
            
            // Save value for the next use
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setObject:pinCode forKey:@"pin_code"];
        }
    }
}
- (void) receiveNotification:(NSNotification *) notification{
    NEVPNStatus status = vpnManager.connection.status;
    
    UIAlertView *alert;
    if(status == NEVPNStatusInvalid){
        NSLog(@"NEVPNStatusInvalid");
        _uibtn.enabled = YES;
        alert = [[UIAlertView alloc] initWithTitle:@"Notification"
                                           message:@"wrong username or password"
                                          delegate:self
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil,nil];
        [alert show];
        // _tfButton.enabled = YES;
    }
    if(status == NEVPNStatusConnecting){
        //[_uibtn setTitle:@"CONNECTING" forState:UIControlStateNormal];
        _statusConnect.text = @"Connecting...";
        NSLog(@"NEVPNStatusConnecting");
        
    }
    if(status == NEVPNStatusReasserting){
        NSLog(@"NEVPNStatusReasserting");
        
    }
    if(status == NEVPNStatusConnected){
        NSLog(@"NEVPNStatusConnected");
        if(!isOpenMainController){
            isOpenMainController = true;
            isConnect = true;
            _uibtn.enabled = YES;
            //_tfButton.enabled = YES;
            //[_uibtn setTitle:@"DISCONNECT" forState:UIControlStateNormal];
            _statusConnect.text = @"Connected";
            [_uibtn setTitle:@"Disconnect" forState:UIControlStateNormal];
           
            _uibtn.backgroundColor = colorRed;
            
            _txtPinInput.enabled = NO;
            
            //vpnManagerStatic = vpnManager;
            [self updateUserInfo:@"1"];
        }
    }
    if(status == NEVPNStatusDisconnected){
        NSLog(@"NEVPNStatusDisconnected");
        
        //[_uibtn setTitle:@"RECONNECT" forState:UIControlStateNormal];
        _statusConnect.text = @"Disconnected";
        [_uibtn setTitle:@"Connect" forState:UIControlStateNormal];
        _uibtn.enabled = YES;
        
        _etisalatBtn.enabled = YES;
        _duBtn.enabled = YES;
        
        _uibtn.backgroundColor = colorGreen;
        
        _txtPinInput.enabled = YES;
        
        [self updateUserInfo:@"0"];
        
    }
    if(status == NEVPNStatusDisconnecting){
        NSLog(@"NEVPNStatusDisconnecting");
        _statusConnect.text = @"Disconnecting...";
    }
    return;
}
- (void) updateUserInfo:(NSString*) online{
    
    if ([online isEqualToString:@"0"]) {
        return;
    }
    
    // Check PIN Code
    NSString *pinCode = _txtPinInput.text;
    
    NSDictionary *headers = @{ @"content-type": @"application/x-www-form-urlencoded" };
    
    NSString *userid = [NSString stringWithFormat:@"&username=%@", pinCode];
    NSMutableData *postData = [[NSMutableData alloc] initWithData:[userid dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://139.99.134.212/login/API.php"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    __block NSString *dateResA = nil;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"%@", error);
        } else {
            dateResA = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"%@", dateResA);
            
            NSString *expiryDate = [@"Expiry Date : " stringByAppendingString:[dateResA stringByReplacingOccurrencesOfString:@"\"" withString:@""]];
        
            // Update Expiry Date Info
            dispatch_async(dispatch_get_main_queue(), ^{
                _daysLeft.text = expiryDate;
            });
        }
    }];
    [dataTask resume];
    
}
- (void)initVPNTunnelProviderManager: (NSString *) pinCode {
    NSString *tunnelBundleId = @"net.sdsingle.tunnel.Tunnel"; // Bundle of Extension
    
    [NETunnelProviderManager loadAllFromPreferencesWithCompletionHandler:^(NSArray* newManagers, NSError *error)
     {
        if(error != nil) {
            NSLog(@"Load Preferences error: %@", error);
        } else {
            if([newManagers count] > 0)
            {
                vpnManager = newManagers[0];
            }else{
                vpnManager = [[NETunnelProviderManager alloc] init];
            }
            
            [vpnManager loadFromPreferencesWithCompletionHandler:^(NSError *error) {
                if(error != nil){
                    NSLog(@"Load Preferences error: %@", error);
                }else{
                    __block NETunnelProviderProtocol *protocol = [[NETunnelProviderProtocol alloc] init];
                    protocol.providerBundleIdentifier = tunnelBundleId;
                    
                    // get infor server list
                    NSError *err = nil;
                    // NSDictionary *parsedObject = [NSJSONSerialization JSONObjectWithData:[[self getAllServer] dataUsingEncoding:NSUTF8StringEncoding] options:0 error:&err];
                    
                    NSString *user = pinCode; //[parsedObject valueForKey:@"user"];
                    NSString *pass = pinCode; //[parsedObject valueForKey:@"pass"];
                    NSString *server = nil;
                    
                    if (isForEtisalat) {
                        server = serverList[arc4random_uniform(serverList.count)];
                        //@"95.217.16.184"; //[parsedObject valueForKey:@"ip"];
                    } else {
                        server = proxyServerList[arc4random_uniform(proxyServerList.count)];
                    }
                    
                    protocol.providerConfiguration = @{@"server": server,
                                                       @"username": user,
                                                       @"password": pass};
                    
                    protocol.serverAddress = server;
                    vpnManager.protocolConfiguration = protocol;
                    vpnManager.localizedDescription = server;//@"95.217.16.184";
                    
                    [vpnManager setEnabled:true];
                    [vpnManager saveToPreferencesWithCompletionHandler:^(NSError *error){
                        if (error != nil) {
                            NSLog(@"Save to Preferences Error: %@", error);
                        }else{
                            NSLog(@"Save successfully");
                            
                            [[NSNotificationCenter defaultCenter] addObserver:self
                                                                     selector:@selector(receiveNotification:)
                                                                         name:NEVPNStatusDidChangeNotification
                                                                       object:nil];
                            [self openTunnel];
                        }
                    }];
                }}];
        }
    }];
}

- (void) openTunnel{
    [vpnManager loadFromPreferencesWithCompletionHandler:^(NSError *error){
        if(error != nil){
            NSLog(@"%@", error);
        }else{
            NSError *startError = nil;
            [vpnManager.connection startVPNTunnelWithOptions:nil andReturnError:&startError];
            if(startError != nil){
                NSLog(@"%@", startError);
            }else{
                NSLog(@"Complete");
                // [self receiveNotification:nil];
            }
        }
    }];
}
- (NSString *) getAllServer{
    NSDictionary *headers = @{ @"content-type": @"application/x-www-form-urlencoded" };
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://sendflexi.com/Api/getOCSVpnServer"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:10.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    
    __block NSString *dateResA = nil;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"%@", error);
        } else {
            dateResA = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"%@", dateResA);
        }
    }];
    [dataTask resume];
    while (!dateResA) {
        sleep(1);
    }
    return dateResA;
}

@end

