//
//  ViewController.h
//  connect
//
//  Created by Chi Yu Lan on 4/11/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *uibtn;

@end

