//
//  PacketTunnelProvider.m
//  ConnectTunnel
//
//  Created by Chi Yu Lan on 4/11/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

#import "PacketTunnelProvider.h"
#import "OpenAdapter.h"
@implementation PacketTunnelProvider{
    OpenAdapter *vpnAdapter;
    NWTCPConnection *_TCPConnection;
    NSDictionary *config;
    NSString *host;
    NSString *username;
    NSString *password;
    NSString *option;
}

- (void)startTunnelWithOptions:(NSDictionary *)options completionHandler:(void (^)(NSError *))completionHandler {
    NSLog(@"===>");
    vpnAdapter = [[OpenAdapter alloc] init];
    vpnAdapter.delegate = self;
    // get config
    config = [[NSDictionary alloc] init];
    NETunnelProviderProtocol *protocol = (NETunnelProviderProtocol *)self.protocolConfiguration;
    config = protocol.providerConfiguration;
    
    host = config[@"server"];
    
    // Load config data
    username = config[@"username"];
    password = config[@"password"];
    
    option = config[@"option"];
    
    // this call core openconnect 
    if(option != nil){
        [vpnAdapter connect:host user:username pass:password add:YES];
    }else{
        [vpnAdapter connect:host user:username pass:password add:NO];
    }
    return;
}

- (void)stopTunnelWithReason:(NEProviderStopReason)reason completionHandler:(void (^)(void))completionHandler {
	// Add code here to start the process of stopping the tunnel.
	completionHandler();
}

- (void)handleAppMessage:(NSData *)messageData completionHandler:(void (^)(NSData *))completionHandler {
	// Add code here to handle the message.
}

- (void)sleepWithCompletionHandler:(void (^)(void))completionHandler {
	// Add code here to get ready to sleep.
	completionHandler();
}

- (void)wake {
	// Add code here to wake up.
}

- (void)openVPNAdapter:(NSError *)error {
  
}

- (void) setupUDPSession: (NEPacketTunnelNetworkSettings *) setting{
    self.reasserting = false;
    NSString *_serverAddress = host;
    NSString *_port = @"443";
    if(_TCPConnection != nil){
        self.reasserting = true;
        _TCPConnection = nil;
    }
    
    [self setTunnelNetworkSettings:nil completionHandler:^(NSError * _Nullable error){
        if(error != nil){
            NSLog(@"Error set TunnelNetwork %@", error);
        }
        // = [self createUDPSessionToEndpoint:[NWHostEndpoint endpointWithHostname:_serverAddress port:_port] fromEndpoint:nil];
        _TCPConnection = [self createTCPConnectionToEndpoint:[NWHostEndpoint endpointWithHostname:_serverAddress port:_port] enableTLS:false TLSParameters:nil delegate:self];
        [self setTunnelNetworkSettings:setting completionHandler:^(NSError * _Nullable error){
            if(error != nil){
                NSLog(@"%@", error);
            }
        }];
    }];
}
- (void)openVPNAdapter:(OpenAdapter * _Nullable)openVPNAdapter configureTunnelWithNetworkSettings:(NEPacketTunnelNetworkSettings * _Nullable)networkSettings completionHandler:(void (^ _Nullable)(id<OpenAdapterPacketFlow> _Nullable))completionHandler {
    [self setupUDPSession:networkSettings];
    NSArray<NEIPv4Route *> *includedRoutes = [[networkSettings IPv4Settings] includedRoutes];
    completionHandler(self.packetFlow);
}

- (void)openVPNAdapter:(OpenAdapter * _Nullable)openVPNAdapter handleError:(NSError * _Nullable)error {
    NSLog(@"ERROR IN HERE");
}

@end
