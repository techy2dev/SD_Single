//
//  PacketTunnelProvider.h
//  ConnectTunnel
//
//  Created by Chi Yu Lan on 4/11/18.
//  Copyright © 2018 Chi Yu Lan All rights reserved.
//

@import NetworkExtension;
#import "OpenConnectAdapter.h"
#import "OpenAdapter.h"
@interface PacketTunnelProvider : NEPacketTunnelProvider <OpenAdapterDelegate>

@end
