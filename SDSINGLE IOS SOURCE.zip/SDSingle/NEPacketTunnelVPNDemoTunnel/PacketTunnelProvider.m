//
//  PacketTunnelProvider.m
//  Tunnel
//[OpenConnectAdapter startWithOptions:@[
//@"--user", @"test33",
//@"us.cisadd.com"]];
//  Created by Tran Viet Anh on 6/15/17.
//  Copyright © 2017 NextVPN Corporation. All rights reserved.
//

#import "PacketTunnelProvider.h"
#import "OpenVPNAdapter.h"
@implementation PacketTunnelProvider{
    NWUDPSession *_UDPSession;
    NSDictionary *config;
}

- (void) setupPacketTunnelNetworkSettings {
    __weak typeof(self) weakSelf = self;
    
    NEPacketTunnelNetworkSettings *tunnelNetworkSettings = [[NEPacketTunnelNetworkSettings alloc] initWithTunnelRemoteAddress:self.protocolConfiguration.serverAddress];//vpn_server_public_ip_address
    
    tunnelNetworkSettings.IPv4Settings = [[NEIPv4Settings alloc] initWithAddresses:@[config[@"ipclient"]]
                                                                       subnetMasks:@[config[@"netmask"]]];
    
    tunnelNetworkSettings.MTU = [NSNumber numberWithInt:[config[@"mtu"] intValue]];
    //NEDNSSettings *dnsSetting = [[NEDNSSettings alloc] initWithServers: @[@"192.168.2.1"]];
    
    [self setTunnelNetworkSettings:tunnelNetworkSettings completionHandler:^(NSError * _Nullable error){
        [weakSelf udpToTun];
    }];
}

- (void) setupUDPSession{
    if(_UDPSession != nil){
        self.reasserting = true;
        _UDPSession = nil;
    }
    self.reasserting = false;
    
    __weak typeof(self) weakSelf = self;
    //NSString *_serverAddress = @"192.168.2.1";
    NSString *_serverAddress = self.protocolConfiguration.serverAddress;
    NSString *_port = @"443";
    
    [self setTunnelNetworkSettings:nil completionHandler:^(NSError * _Nullable error){
        if(error != nil){
            NSLog(@"Error set TunnelNetwork %@", error);
        }else{
            _UDPSession = [self createUDPSessionToEndpoint:[NWHostEndpoint endpointWithHostname:_serverAddress port:_port] fromEndpoint:nil];
            [weakSelf setupPacketTunnelNetworkSettings];
        }
        
    }];
}

- (void) tunToUDP{
    __weak typeof(self) weakSelf = self;
    [weakSelf.packetFlow readPacketsWithCompletionHandler:^(NSArray<NSData *> * _Nonnull packets, NSArray<NSNumber *> * _Nonnull protocols) {
        for(NSData *packet in packets){
            // This is where encrypt() should reside
            // A comprehensive encryption is not easy and not the point for this demo
            // I just omit it
            [_UDPSession writeDatagram:packet completionHandler:^(NSError * _Nullable error) {
                [weakSelf setupUDPSession];
                return;
            }];
        }
    }];
}

- (void) udpToTun{
    __weak typeof(self) weakSelf = self;
    [_UDPSession setReadHandler:^(NSArray<NSData *> * _Nullable _packets, NSError * _Nullable error) {
        // This is where decrypt() should reside, I just omit it like above
        NSArray *protocols = [NSMutableArray arrayWithCapacity:_packets.count];
        [weakSelf.packetFlow writePackets:_packets withProtocols:protocols];
    } maxDatagrams:NSIntegerMax];
    
}
- (void)startTunnelWithOptions:(NSDictionary *)options completionHandler:(void (^)(NSError *))completionHandler
{
    config = [[NSDictionary alloc] init];
    NETunnelProviderProtocol *aaa = (NETunnelProviderProtocol *)self.protocolConfiguration;
    config = aaa.providerConfiguration;
    [self setupUDPSession];
    [self tunToUDP];
}

- (void)stopTunnelWithReason:(NEProviderStopReason)reason completionHandler:(void (^)(void))completionHandler
{
    completionHandler();
}

- (void)handleAppMessage:(NSData *)messageData completionHandler:(void (^)(NSData *))completionHandler
{
    // Add code here to handle the message.
}

- (void)sleepWithCompletionHandler:(void (^)(void))completionHandler
{
    // Add code here to get ready to sleep.
    completionHandler();
}

- (void)wake
{
    // Add code here to wake up.
}

- (void)openVPNAdapter:(NSError *)error {
    // error
}

- (void)openVPNAdapter:(NEPacketTunnelNetworkSettings *)networkSettings completionHandler:(void (^)(id<OpenVPNAdapterPacketFlow> _Nullable))completionHandler {
    // setting
}

@end
