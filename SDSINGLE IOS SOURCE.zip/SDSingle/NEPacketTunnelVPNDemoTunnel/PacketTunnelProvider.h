//
//  PacketTunnelProvider.h
//  NEPacketTunnelVPNDemoTunnel
//
//  Created by Tran Viet Anh on 8/14/17.
//  Copyright © 2017 NextVPN Corporation. All rights reserved.
//

@import NetworkExtension;
#import "OpenconnectClient.h"
@interface PacketTunnelProvider : NEPacketTunnelProvider <OpenVPNAdapterDelegate>

@end
